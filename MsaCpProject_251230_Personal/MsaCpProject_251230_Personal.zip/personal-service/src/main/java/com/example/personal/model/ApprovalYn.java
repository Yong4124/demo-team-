package com.example.personal.model;

public enum ApprovalYn {
    Y,  // 승인
    N   // 미승인
}