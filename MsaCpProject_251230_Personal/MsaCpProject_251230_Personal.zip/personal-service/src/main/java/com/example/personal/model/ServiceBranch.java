package com.example.personal.model;

public enum ServiceBranch {
    KATUSA,
    ROK_AIR_FORCE,
    ROK_ARMY,
    ROK_MARINE_CORPS,
    ROK_NAVY,
    ROKA_SUPPORT_GROUP,
    US_AIR_FORCE,
    US_ARMY,
    US_DOD_PERSONNEL,
    US_MARINE_CORPS,
    US_NAVY
}
