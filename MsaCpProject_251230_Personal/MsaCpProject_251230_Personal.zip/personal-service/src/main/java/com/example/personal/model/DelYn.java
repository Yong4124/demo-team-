package com.example.personal.model;

public enum DelYn {
    Y,  // 삭제
    N   // 미삭제
}