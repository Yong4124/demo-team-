package com.example.personal.model;

public enum ServiceCategory {
    USFK,
    KATUSA,
    CFC_ROK,
    RETIRED_MND_JCS_SERVICES_ROK    // Retired MND,JCS,and/or services(ROK)
}
