package com.example.personal.model;

public enum Residence {
    O,  // 기타
    K,  // 대한민국
    U   // 미국
}